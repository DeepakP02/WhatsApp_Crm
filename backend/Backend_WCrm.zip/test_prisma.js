import prisma from './src/config/prisma.js';
console.log(Object.keys(prisma));
